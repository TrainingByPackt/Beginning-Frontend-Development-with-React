import React from 'react';

class Cart extends React.Component {
  render() {
    return <div><h2>Cart</h2></div>;
  }
}

export default Cart;
